/**
 * Import styles for HTML galleys
 */
import './galley.css'
