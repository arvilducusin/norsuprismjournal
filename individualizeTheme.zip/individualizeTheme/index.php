<?php

use APP\plugins\themes\individualizeTheme\IndividualizeTheme;

return new IndividualizeTheme();
