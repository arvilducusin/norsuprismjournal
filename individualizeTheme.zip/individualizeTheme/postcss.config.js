export default {
  plugins: {
    autoprefixer: {},
    'postcss-nesting': {},
    'postcss-custom-media': {},
    'tailwindcss/nesting': {},
    tailwindcss: {},
  },
}
